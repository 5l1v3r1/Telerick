-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 08, 2013 at 04:44 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `user`
--
CREATE DATABASE `user` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `user`;

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE IF NOT EXISTS `message` (
  `Mess_id` int(11) NOT NULL AUTO_INCREMENT,
  `Mess_Title` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `user` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`Mess_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`Mess_id`, `Mess_Title`, `message`, `user`, `date`) VALUES
(1, 'OPTIMUM NUTRITION 100% Whey Gold Standard', 'Optimum Gold Standard 100% Protein е бил най-продаваната хранителна добавка в културизма. Това е продукт за тези, които се опитват да покачат чиста мускулна маса! Изолат на суроватъчен протеин се състои от 90% чист протеин', 'ivann', '2013-10-08 17:40:15'),
(2, 'AMIX CellEx ® Unlimited Powder 520g', 'Amix CellEx Unlimited e изключителна увеличаваща обема добавка с Muscle Cell и N.O. (MC &N.O.) за преди тренировка, създадена от AMIX. Тази единствена по рода си формула зарежда с енергия и стимулира физическото изпълнение', 'ivann', '2013-10-08 17:41:16'),
(3, 'USP LABS Jack3d Micro 145g.', 'Срещали ли сте вече новия Jack3d Micro на USPlabs? Изследвана и формулирана от създателите на оригиналния Jack3d, който направи революция в предтренировъчната категория ...', 'ivann', '2013-10-08 17:41:51');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `User_ID` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  PRIMARY KEY (`User_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`User_ID`, `user`, `password`) VALUES
(1, 'ivann', '123123');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
